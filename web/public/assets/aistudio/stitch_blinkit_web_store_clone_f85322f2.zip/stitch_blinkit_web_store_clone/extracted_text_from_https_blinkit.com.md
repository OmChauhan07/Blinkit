access denied 

sorry, you have been blocked! 

 

The page you are trying to access has blocked you, your recent actions performed on the website might have led to his. If you wish to proceed further and gain access to this page, please complete the challenge below: 

Enable JavaScript and cookies to continue

Ray ID - a541523e98f6479e Your IP - 74.125.214.65

#### #1 instant delivery service in India

Shop on the go and get anything delivered in 10 minutes (or less). Buy everything from groceries to fresh fruits & vegetables, cakes and bakery items, to meats & seafood, cosmetics, mobiles & accessories, electronics, baby care products and much more. We get it delivered at your doorstep in the fastest and the safest way possible.

#### single app for all your daily needs

Order thousands of products at just a tap - milk, eggs, bread, cooking oil, ghee, atta, rice, fresh fruits & vegetables, spices, chocolates, chips, biscuits, Maggi, cold drinks, shampoos, soaps, body wash, pet food, diapers, electronics, other organic and gourmet products from your neighbourhood stores and a lot more.

#### order online on Blinkit to enjoy instant delivery magic

Cities we currently serve: Agra, Ahmedabad, Bengaluru, Chandigarh, Chennai, Delhi, Faridabad, HR-NCR, Hyderabad, Jaipur, Jalandhar, Kanpur, Kolkata, Lucknow, Mathura, Meerut, Mohali, Mumbai, Panchkula, Pune, UP-NCR